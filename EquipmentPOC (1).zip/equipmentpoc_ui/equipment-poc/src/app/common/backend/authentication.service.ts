import { Injectable } from '@angular/core';
import { UserService } from './user.service';
import { CryptoService } from './crypto.service';

@Injectable({ providedIn: 'root' })
/**
 * Authentication Service class used for client auth functions.
 */
export class AuthenticationService {

    /** The sessionStorage key for the current user. */
    private readonly currentUser: string = 'currentUser_LocalStorage_Key';
    private readonly currentLocation: string = 'currentLocation_LocalStorage_Key';

    /** A random encryption key for storing user in session. */
    private readonly randomKey: string = '-ew^b%qtWJ69HA[';

    redirectUrl: string;

    /**
     * Initializes a new instance of AuthenticationService class.
     * @param cryptoService Inject CryptoService instance for cryptography functions.
     * @param userService Inject UsersService instance for Users DB management functions.
     */
    constructor(private cryptoService: CryptoService, private userService: UserService) {
        this.redirectUrl = ``;
    }

    /**
     * Function to try signing in a specific user.
     * @param username Username of the user trying to sign in.
     * @returns Boolean value for sign in success state (true = sucess; false = fail).
     */
    public signIn(username: string, location: string): boolean {
        const isUserAuthenticated = true;
        if (isUserAuthenticated) {
            sessionStorage.setItem(this.currentUser, this.cryptoService.encrypt(username, this.randomKey));
            sessionStorage.setItem(this.currentLocation, this.cryptoService.encrypt(location, this.randomKey));
            return true;
        }
        return false;
    }

    /**
     * Function to sign out a user. This deletes user session in sessionStorage.
     */
    public signOut(): void {
        sessionStorage.removeItem(this.currentUser);
        sessionStorage.removeItem(this.currentLocation);
    }

    /**
     * Function to retrieve a decrypted username of the current User in sessionStorage.
     * @returns Value of the decrypted username. Null if does not exist.
     */
    public retrieveUsername(): string | null {
        const userSession: string | null = sessionStorage.getItem(this.currentUser);
        return !userSession ? null : this.cryptoService.decrypt(userSession, this.randomKey);
    }

    /**
     * Function to retrieve a decrypted username of the current User in sessionStorage.
     * @returns Value of the decrypted username. Null if does not exist.
     */
    public retrieveLocation(): string | null {
        const locationSession: string | null = sessionStorage.getItem(this.currentLocation);
        return !locationSession ? null : this.cryptoService.decrypt(locationSession, this.randomKey);
    }

    /**
     * Checks to see if the User exists in sessionStorage AND Users localStorage database.
     * @returns True if the above conditions are met, otherwise, false.
     */
    public isSignedIn(): boolean {
        const encrypedUser: string | null = sessionStorage.getItem(this.currentUser);
        if (!encrypedUser) {
            return false;
        }

        return this.isAuthenticated(this.cryptoService.decrypt(encrypedUser, this.randomKey));
    }

    /**
     * Checks to see if the User is in the localStorage Users database.
     * @param username OPTIONAL. Decrypted username to authenticate. Gets current user if null.
     */
    private isAuthenticated(username?: string | null): boolean {
        if (!username) {
            username = this.cryptoService.decrypt(sessionStorage.getItem(this.currentUser) || '', this.randomKey);
        }

        if (this.userService.readUser(username)) {
            return true;
        }

        return false;
    }


}
