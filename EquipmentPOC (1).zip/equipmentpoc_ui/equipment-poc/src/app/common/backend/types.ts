export interface Equipment {
    equipid: string;
    equiptype: string;
    equipdesc: string;
    checkdate: string;
    Checktime: string;
    passorfail: string;
    inservice: string;
    equipment_img_url: string;
}
