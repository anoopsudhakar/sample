import { RecentEquipment } from '../../warehouse/models/recent-equipment.model';
import { EquipmentChecklist } from '../../warehouse/models/equipment-checklist.model';
import { EquipmentDetails } from '../../warehouse/models/equipment-details.model';
import { EquipmentChecklistHistory } from '../../warehouse/models/equipment-checklist-history.model';

export const mockEquipments: RecentEquipment[] = [
    {
        equipid: '14    ',
        equiptype: 'X',
        equipdesc: 'SCISSOR LIFT US',
        checkdate: '2020-12-08',
        checktime: '1435',
        passorfail: 'P',
        inservice: 'Y',
        vinno: 'A268N23834S      '
      },
      {
        equipid: '6     ',
        equiptype: 'F',
        equipdesc: 'FORKLIFT       ',
        checkdate: '2020-12-16',
        checktime: '703',
        passorfail: 'P',
        inservice: 'Y',
        vinno: 'A268N12070L      '
      },
      {
        equipid: '7     ',
        equiptype: 'F',
        equipdesc: 'FORKLIFT       ',
        checkdate: '2020-12-11',
        checktime: '1628',
        passorfail: 'P',
        inservice: 'Y',
        vinno: 'A268N23833S      '
      }
];

export const mockEquipmentDetails: EquipmentDetails[] = [
    {
        equipwhs: '171',
        equipunit: '6     ',
        laststs: 'F',
        lastchkdt: '2021-02-08',
        // lastchktime: '1324',
        hrsused: '1234567',
        inservice: 'Y',
        equiptype: 'F',
        equipdesc: 'FORKLIFT                           ',
        lastuser: 'LLD',
        mfg: 'HYSTER         ',
        equipyear: '2014',
        vinno: 'X128619273'
    }
];

export const mockEquipmentChecklist: EquipmentChecklist[] = [
    {
        equipChklistItemDesc: 'Battery (Charge Gates, EPO)',
        equipChklistItemDetail: 'This icon will be ON when the key switch is ON and the engine is not running. The icon must go OFF when the engine is running.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F01.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F01.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '1',
        timestamp: '2020-12-17T18:42:04.9387429+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9387429Z\'"'
    },
    {
        equipChklistItemDesc: 'Brakes (Plugging & Deadman)',
        equipChklistItemDetail: 'The inching/brake pedal is used to control the inching operation. During operation as the inching/brake pedal is applied, the clutch in the transmission gradually disengages while the brakes engage.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F10.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F10.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '10',
        timestamp: '2020-12-28T13:38:46.8879296+00:00',
        eTag: 'W/"datetime\'2020-12-28T13%3A38%3A46.8879296Z\'"'
    },
    {
        equipChklistItemDesc: 'Lift/Lower',
        equipChklistItemDetail: 'The lift/lower control lever can be either the first manual lever or first mini-lever to the right of the operator\'s seat. Pull backward toward the operator to raise the carriage and forks. Push forward to lower the carriage and forks.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F11.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F11.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '11',
        timestamp: '2020-12-17T18:42:04.9387429+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9387429Z\'"'
    },
    {
        equipChklistItemDesc: 'Tilt (Auxiliary Functions)',
        equipChklistItemDetail: 'These trucks can be equipped with Return to Set Tilt (RTST) option if truck has manual hydraulic levers. The vertical stop position will be set at the factory. Push the tilt lever knob switch while moving the mast forward or backward, with a light load, the mast will return to vertical position. To stop RTST, release the tilt lever knob switch. RTST is intended as an operator aid in positioning forks or attachments for their application to minimize product damage and facilitate load handling. Care should be taken to operate the truck in accordance with load handling instructions as described in Operating Techniques on the Operating Procedures section of this Operating Manual.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F12.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F12.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '12',
        timestamp: '2020-12-17T18:42:04.9397439+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9397439Z\'"'
    },
    {
        equipChklistItemDesc: 'Restraint Devices (OP-UP)',
        equipChklistItemDetail: 'Make sure the seat rails and latch striker are not loose. The seat rails must lock tightly in position, but move freely when unlocked. The seat rails must be correctly fastened to the hood and the hood fastened to the hinges on the frame. Try to lift the hood to make sure it is fastened correctly and will not move. If adjustment is required, go to Hood Latch Check in the Periodic Maintenance section of the service manual.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F13.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F13.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '13',
        timestamp: '2020-12-17T18:42:04.9397439+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9397439Z\'"'
    },
    {
        equipChklistItemDesc: 'Forks Locking Pins',
        equipChklistItemDetail: 'Inspect the channels for wear in the areas where the rollers travel. Inspect the rollers for wear or damage.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F02.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F02.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '2',
        timestamp: '2020-12-17T18:42:04.9397439+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9397439Z\'"'
    },
    {
        equipChklistItemDesc: 'Frond End (Mast & Carriage)',
        equipChklistItemDetail: 'Inspect the welds on the mast, cylinders, and carriage for cracks. Make sure that the capscrews and nuts are tight.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F03.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F03.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '3',
        timestamp: '2020-12-17T18:42:04.9397439+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9397439Z\'"'
    },
    {
        equipChklistItemDesc: 'Tires & Wheels',
        equipChklistItemDetail: 'Check the tires for damage. Check the tread and remove any objects that will cause damage. Check for bent or damaged rims. Check for loose or missing hardware. Remove any wire, strapping, or other material that is wrapped around the axle.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F04.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F04.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '4',
        timestamp: '2020-12-17T18:42:04.9397439+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9397439Z\'"'
    },
    {
        equipChklistItemDesc: 'Oil Leaks',
        equipChklistItemDetail: 'Visually inspect hoses/fittings for hydraulic leaks; hose cover for cuts, cracks, or exposed reinforcement; defective/ broken clamping devices or sheaves; and proper tracking during operation. Adjust/repair/replace hose/components as necessary.',
        url: 'https://sqlvaukau6rgozyd5k.blob.core.windows.net/depot-equip-images/F05.jpg',
        container: 'depot-equip-checklist-images',
        fileName: 'F05.jpg',
        strorageAccount: 'sqlvaukau6rgozyd5k',
        partitionKey: 'F',
        rowKey: '5',
        timestamp: '2020-12-17T18:42:04.9407448+00:00',
        eTag: 'W/"datetime\'2020-12-17T18%3A42%3A04.9407448Z\'"'
    }
];

export const mockEquipmentChecklistHistory: EquipmentChecklistHistory[] = [
    {
      equipwhs: '171',
      equiptype: 'F',
      equiptypedesc: null,
      chkdt: '2021-02-04',
      chktime: '834',
      chkuser: 'LLD',
      chkhours: '5468000',
      cia: '010203040506080910111213000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
      cda: 'BATTERY (CHARGE GATES, EPO)        FORKS LOCKING PINS                 FRONT END (MAST & CARRIAGE)        TIRES & WHEELS                     OIL LEAKS                          OVERHEAD GUARD                     LIGHTS ALL & HORN                  DIRECTIONAL/SPEED CONTROL(PLUGGING)BRAKES (PLUGGING & DEADMAN)        LIFT/LOWER                         TILT (AUXILLARY FUNCTIONS)         RESTRAINT DEVICES (OP-UP)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ',
      cra: 'PPPPPPPPPPPP                                                                                       '
    },
    {
      equipwhs: '171',
      equiptype: 'F',
      equiptypedesc: null,
      chkdt: '2021-02-03',
      chktime: '1703',
      chkuser: 'BNW',
      chkhours: '1234500',
      cia: '010203040506080910111213000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
      cda: 'BATTERY (CHARGE GATES, EPO)        FORKS LOCKING PINS                 FRONT END (MAST & CARRIAGE)        TIRES & WHEELS                     OIL LEAKS                          OVERHEAD GUARD                     LIGHTS ALL & HORN                  DIRECTIONAL/SPEED CONTROL(PLUGGING)BRAKES (PLUGGING & DEADMAN)        LIFT/LOWER                         TILT (AUXILLARY FUNCTIONS)         RESTRAINT DEVICES (OP-UP)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ',
      cra: 'PPPPPPPPPPPP                                                                                       '
    },
    {
      equipwhs: '171',
      equiptype: 'F',
      equiptypedesc: null,
      chkdt: '2021-02-03',
      chktime: '1654',
      chkuser: 'BNW',
      chkhours: '2233446',
      cia: '010203040506080910111213000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
      cda: 'BATTERY (CHARGE GATES, EPO)        FORKS LOCKING PINS                 FRONT END (MAST & CARRIAGE)        TIRES & WHEELS                     OIL LEAKS                          OVERHEAD GUARD                     LIGHTS ALL & HORN                  DIRECTIONAL/SPEED CONTROL(PLUGGING)BRAKES (PLUGGING & DEADMAN)        LIFT/LOWER                         TILT (AUXILLARY FUNCTIONS)         RESTRAINT DEVICES (OP-UP)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ',
      cra: 'PPPPPPPPPPPP                                                                                       '
    },
    {
      equipwhs: '171',
      equiptype: 'F',
      equiptypedesc: null,
      chkdt: '2021-02-03',
      chktime: '1629',
      chkuser: 'BNW',
      chkhours: '1234567',
      cia: '010203040506080910111213000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
      cda: 'BATTERY (CHARGE GATES, EPO)        FORKS LOCKING PINS                 FRONT END (MAST & CARRIAGE)        TIRES & WHEELS                     OIL LEAKS                          OVERHEAD GUARD                     LIGHTS ALL & HORN                  DIRECTIONAL/SPEED CONTROL(PLUGGING)BRAKES (PLUGGING & DEADMAN)        LIFT/LOWER                         TILT (AUXILLARY FUNCTIONS)         RESTRAINT DEVICES (OP-UP)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ',
      cra: 'PPPPPPPFPPPP                                                                                       '
    },
    {
      equipwhs: '171',
      equiptype: 'F',
      equiptypedesc: null,
      chkdt: '2021-02-03',
      chktime: '1226',
      chkuser: 'LLD',
      chkhours: '1234567',
      cia: '010203040506070809101100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
      cda: 'BATTERY (CHARGE GATES, EPO)        FORKS LOCKING PINS                 FRONT END (MAST & CARRIAGE)        TIRES & WHEELS                     OIL LEAKS                          OVERHEAD GUARD                     LIGHTS ALL & HORN                  DIRECTIONAL/SPEED CONTROL(PLUGGING)BRAKES (PLUGGING & DEADMAN)        LIFT/LOWER                         TILT (AUXILLARY FUNCTIONS)         RESTRAINT DEVICES (OP-UP)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ',
      cra: 'PPPPPPPPPPPF                                                                                        '
    }
  ];
