import { Injectable } from '@angular/core';
import { UserModel } from './user.model';

@Injectable({ providedIn: 'root' })
/**
 * Users Service class used in managing localStorage database.
 */
export class UserService {

    /**
     * Initializes a new instance of UsersService class.
     */
    constructor() { }

    /**
     * Retrieves a specific User from localStorage database.
     * @param username Username of the User to retrieve.
     * @returns The User object.
     */
    public readUser(username: string): UserModel {
        return this.getUserFromWebService();
    }

    /**
     * Retrieves a specific User from localStorage database.
     * @returns The User object.
     */
    private getUserFromWebService(): UserModel {

        /* This is where we get the authenticated user. */
        const userModel: UserModel = {
            username: `costco-user`,
            firstName: `Costco`,
            lastName: `User`,
            avatarUrl: `` };

        return userModel;
    }
}
