import { Component, OnInit, OnDestroy } from '@angular/core';
import { EquipmentTotalService } from 'src/app/back-office/Backofficeservice/equipment-total.service';
import { EquipmentImage } from '../../../common/models/equipment-image';
import { Subscription } from 'rxjs/internal/Subscription';
import { SharedServiceService } from 'src/app/back-office/Backofficeservice/shared-service.service';
import { FormGroup, FormControl, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
@Component({
  selector: 'app-search-equipment',
  templateUrl: './search-equipment.component.html',
  styleUrls: ['./search-equipment.component.less']
})
export class SearchEquipmentComponent implements OnInit, OnDestroy {
  equipmentList: any[] = [];
  ynFormat: any;
  locationNumber: any;
  defaultImageUrl?: string;
  sharedvalue: any;
  subscription!: Subscription;
  equiomentMenu: any[] = [];
  equipmentStatus: any[] = [];
  hrsLogged: any[] = [];
  menuForm: FormGroup = new FormGroup({});
  statusForm: FormGroup = new FormGroup({});
  hrsLoggedForm: FormGroup = new FormGroup({});
  checkdate: string = '';
  endpoint: string = 'Y/Y/Y/Y/Y/Y/Y/Y/Y/Y/Y/Y/Y/Y';
  constructor(
    private equipmentService: EquipmentTotalService,
    private sharedService: SharedServiceService,
    private router: Router
  ) {
    this.defaultImageUrl = `../../assets/costco-c-logo.webp`;
    this.locationNumber = '';
  }

  ngOnInit(): void {
    this.locationNumber = localStorage.getItem('locationNumber');
    this.subscription = this.sharedService.navItem$
      .subscribe(e => this.sharedvalue = e);
    this.menuForm = new FormGroup({
      0: new FormControl(false),
      1: new FormControl(false),
      2: new FormControl(false),
      3: new FormControl(false),
      4: new FormControl(false),
      5: new FormControl(false),
      6: new FormControl(false),
      7: new FormControl(false),
      8: new FormControl(false)
      //equipmentName1: new FormArray([])
    });
    this.statusForm = new FormGroup({
      //equipmentStatusGrp: new FormControl('')
      0: new FormControl(false),
      1: new FormControl(false),
      2: new FormControl(false),
      3: new FormControl(false),
      4: new FormControl(false)
    });

    /*this.hrsLoggedForm = new FormGroup({
      hrsLogged: new FormControl('')
    });*/
    if (this.sharedvalue) {
      let optionIsCheckedArr = [];
      optionIsCheckedArr = this.sharedvalue.split("/")
      console.log(optionIsCheckedArr);
      this.endpoint = optionIsCheckedArr.join("/");
      this.statusForm.patchValue({
        0: optionIsCheckedArr[0] == 'Y' ? true : false,
        1: optionIsCheckedArr[1] == 'Y' ? true : false,
        2: optionIsCheckedArr[2] == 'Y' ? true : false,
        3: optionIsCheckedArr[3] == 'Y' ? true : false,
        4: optionIsCheckedArr[4] == 'Y' ? true : false,
      })
      this.menuForm.patchValue({
        0: optionIsCheckedArr[5] == 'Y' ? true : false,
        1: optionIsCheckedArr[6] == 'Y' ? true : false,
        2: optionIsCheckedArr[7] == 'Y' ? true : false,
        3: optionIsCheckedArr[8] == 'Y' ? true : false,
        4: optionIsCheckedArr[9] == 'Y' ? true : false,
        5: optionIsCheckedArr[10] == 'Y' ? true : false,
        6: optionIsCheckedArr[11] == 'Y' ? true : false,
        7: optionIsCheckedArr[12] == 'Y' ? true : false,
        8: optionIsCheckedArr[13] == 'Y' ? true : false,
      })
    }
    this.getequipmentstatusOptions();
    this.getequipmentdetails(this.locationNumber, this.sharedvalue);
    // this.getHrsloggedOptions();

  }

  getequipmentdetails(locationNumber: string, sharedvalue: string) {
    this.equipmentList = [];
    // if(!sharedvalue){
    this.equipmentService.getEachaAction(locationNumber, sharedvalue).subscribe(fetchedEquipmentDetails => {
      this.equipmentList = fetchedEquipmentDetails;
      this.parseImageUrl();
    });
    // }
    this.calcCheckstatus();
    this.equipmentService.getYNurl().subscribe(res => {
      this.equiomentMenu = res;
    });
  }
  calcCheckstatus() {
    let todaysDate = moment(new Date());
    let formatteddate = todaysDate.format('YYYY-MM-DD');
    this.checkdate = formatteddate;
  }

  parseImageUrl(): void {
    for (const [key, value] of Object.entries(this.equipmentList)) {
      let equipmentImageJSON: EquipmentImage;
      const equipmentType = value.equiptype || '';
      this.equipmentService.getEquipmentImage(equipmentType).subscribe(fetchedEquipmentImageJSON => {
        equipmentImageJSON = fetchedEquipmentImageJSON;
        value.equipmentimgurl = equipmentImageJSON === null ? (value.equipmentimgurl || this.defaultImageUrl) : equipmentImageJSON.url;
      });
    }
  }
  getequipmentstatusOptions() {
    this.equipmentService.getStatusUrl().subscribe(res => {
      this.equipmentStatus = res;
    });
  }
  equipmentCheck(item: any, event: any) {
    let endpointarr = this.endpoint.split('/');
    if (event.target.checked == true) {
      endpointarr[item.id] = 'Y';
      this.endpoint = endpointarr.join("/");
      this.getequipmentdetails(this.locationNumber, this.endpoint);
    }
    else if (event.target.checked == false) {
      endpointarr[item.id] = 'N';
      this.endpoint = endpointarr.join("/");
      this.getequipmentdetails(this.locationNumber, this.endpoint);
    }
    console.log(this.endpoint);
  }
  //statusAction(equipStatus: string, event:any) {
  //console.log(equipStatus);
  // this.equipmentService.getStatusUrl().subscribe(res => {
  //   this.equipmentStatus = res;
  //   let result = this.equipmentStatus.filter((statusArr) => statusArr.status === equipStatus.trim());
  //   for (var [key, item] of result.entries()) {
  //     this.getequipmentdetails(this.locationNumber, item.url);
  //   }
  // });
  //}
  sendCheckedEquipments(index: number) {
    let selectedobj = this.equiomentMenu.filter((element) => element.checked);
    for (var [key, item] of selectedobj.entries()) {
      this.getequipmentdetails(this.locationNumber, item.url);
    }
  }
  // getHrsloggedOptions() {
  //   this.equipmentService.getHrsloggedUrl().subscribe(res => {
  //     this.hrsLogged = res;
  //   });
  // }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}


