import { Component, OnInit, Input } from '@angular/core';
import { AuthenticationService } from '../../../common/backend/authentication.service';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.less']
})
export class WelcomeComponent implements OnInit {
  @Input() currentUsername: string;

  constructor(private authService: AuthenticationService) {
    this.currentUsername = ``;
  }

  ngOnInit(): void {
    this.checkUser();
  }
  checkUser(): void {
    this.currentUsername = this.authService.retrieveUsername() ?? `unknown user`;
  }
}
