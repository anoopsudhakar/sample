import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SigninPageComponent } from './common/components/signin-page/signin-page.component';

import { BackOfficeHomeComponent } from './back-office/components/back-office-home/back-office-home.component';

import { EquipmentChecklistComponent } from './warehouse/components/equipment-checklist/equipment-checklist.component';
import { ChecklistComponent } from './warehouse/components/checklist/checklist.component';
import { ChecklistEquipmentDetailsComponent } from './warehouse/components/checklist-equipment-details/checklist-equipment-details.component';
import { EquipmentDetailsPageComponent } from './warehouse/components/equipment-details-page/equipment-details-page.component';
import { ScannerComponent } from './common/components/scanner/scanner.component';
import { SearchEquipmentComponent } from './common/components/search-equipment/search-equipment.component';
import { ReportsComponent } from './back-office/components/reports/reports.component';

const routes: Routes = [
  { path: '', redirectTo: '/signin', pathMatch: 'full' },
  { path: 'signin', component: SigninPageComponent },
  { path: 'signout', redirectTo: '/signin' },
  { path: 'warehouse', component: EquipmentChecklistComponent }, /* Warehouse Home Page */
  { path: 'office', component: BackOfficeHomeComponent }, /* Back Office Home Page */
  { path: 'checklist/new/:equipmentType/:equipmentID', component: ChecklistComponent },
  { path: 'equipmentdetails/:equipmentID', component: EquipmentDetailsPageComponent },
  { path: 'equipmentdetails/:equipmentID/:locationNumber', component: EquipmentDetailsPageComponent },
  { path: 'scanner', component: ScannerComponent },
  { path: 'search', component: SearchEquipmentComponent },
  { path: 'reports', component: ReportsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
