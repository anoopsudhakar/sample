import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {
  private _navItemSource = new BehaviorSubject(0);
  navItem$ = this._navItemSource.asObservable();

  constructor() { }

  changeNav(ynFormat: any) {
    this._navItemSource.next(ynFormat);
  }

}

