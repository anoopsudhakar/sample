import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EquipmentImage } from '../../common/models/equipment-image';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })

};
@Injectable({
  providedIn: 'root'
})
export class EquipmentTotalService {
  equipmentServicesUrl = 'https://equipmentpocservices.azurewebsites.net/api/EquipmentServices';
  url = '../assets/equipmentTotal.json';
  urlsearch = '../assets/searchequip.json';
  ynjsonurl = '../assets/ynFormat.json';
  statusUlr = '../assets/sideStatusFilters.json';
  constructor(private http: HttpClient) { }

  getEquipmentTotal(location: string): Observable<any> {
    // return this.http.get<any[]>(this.url);
    return this.http.get<any[]>(`${this.equipmentServicesUrl}/GetEquipTotals/${location}`, httpOptions);
  }
  getEquipmentImage(equipmentType: string): Observable<EquipmentImage> {
    return this.http.get<EquipmentImage>(`${this.equipmentServicesUrl}/GetEquipImage/${equipmentType}`, httpOptions);
  }
  getEachaAction(location: string, ynFormat: string): Observable<any> {
   // return this.http.get<any[]>(this.urlsearch);
   return this.http.get<any[]>(`${this.equipmentServicesUrl}/GetEquipList/${location}/${ynFormat}`, httpOptions);
  }
  getYNurl(): Observable<any> {
    return this.http.get<any[]>(this.ynjsonurl);
  }

  getStatusUrl(): Observable<any> {
    return this.http.get<any[]>(this.statusUlr);
  }
}







