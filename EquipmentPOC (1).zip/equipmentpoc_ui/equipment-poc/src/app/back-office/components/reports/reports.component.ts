import { Component, OnInit } from '@angular/core';
import { ChartType, ChartOptions, Chart } from 'chart.js';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EquipmentTotalService } from 'src/app/back-office/Backofficeservice/equipment-total.service';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })
};

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.less']
})

export class ReportsComponent implements OnInit {
  // failedlastYr = '../assets/lastYearFailedReport.json';
  pieChartLabels: any[] = [];
  pieChartData: any[] = [];
  public pieChartColors: any[] = [];
  equipmentFailed: any[] = [];

  public optionsPie = {
    responsive: true,
    scaleBeginAtZero: true
  }
  
  chart: any;
  public piechartBg: any = [{backgroundColor: this.pieChartColors}];
  constructor(private http: HttpClient,private equipmentService: EquipmentTotalService) {}

  ngOnInit(): void {
    //window.dispatchEvent(new Event('resize'));
    this.setFailedEquipLastYr();
  }

  getfailedEquipLastYr(): Observable<any> { console.log(this.equipmentService.equipmentServicesUrl);
    //return this.http.get<any[]>(this.failedlastYr);
    return this.http.get<any[]>(`${this.equipmentService.equipmentServicesUrl}/GetFailedEquip`, httpOptions);
  }

  createDynamicColors() {
    var r = Math.floor(Math.random() * 255);
    var g = Math.floor(Math.random() * 255);
    var b = Math.floor(Math.random() * 255);
    return "rgb(" + r + "," + g + "," + b + ")";
  }
  setFailedEquipLastYr() {

    this.getfailedEquipLastYr().subscribe(fetchFailedDetails => {
      this.equipmentFailed = fetchFailedDetails;
      this.equipmentFailed.forEach((element: any, index: any) => {
        this.pieChartLabels.push(element.descr);
        this.pieChartData.push(element.fails);
      });

      for (var i in this.equipmentFailed) {
        if(this.equipmentFailed.length != this.pieChartColors.length+1){
          this.pieChartColors.push(this.createDynamicColors());
        }
      }
    });

    setTimeout(() => {
      this.renderPieChart();
    }, 100);

   

  }
  chartClicked(e: any): void {
    console.log(e);
  }

  chartHovered(e: any): void {
    console.log(e);
  }

  renderPieChart() {
    this.chart = new Chart('piechart', {
      type: 'pie',
      data: {
        labels: this.pieChartLabels,
        datasets: [
          {
            data: this.pieChartData,
            backgroundColor: this.pieChartColors,
            fill: true
          },
        ]
      },
      options: {
        maintainAspectRatio: true,
        responsiveAnimationDuration:2,
        responsive: true,
        tooltips: {
          enabled: true
        },
        legend: {
          position: 'right',
          labels: {
              fontColor: "#6E6E6E",
              boxWidth: 20,
              padding: 20,
              fontSize: 12
          }
      }
      }
    });
  }
}