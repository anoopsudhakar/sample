import { Component, Input, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../common/backend/authentication.service';

import { Chart } from 'chart.js';
import { EquipmentTotalService } from '../../Backofficeservice/equipment-total.service';
import { EquipmentImage } from '../../../common/models/equipment-image';
import { Router } from '@angular/router';
import { SharedServiceService } from '../../Backofficeservice/shared-service.service';

@Component({
  selector: 'app-backoffice-home',
  templateUrl: './back-office-home.component.html',
  styleUrls: ['./back-office-home.component.less']
})
export class BackOfficeHomeComponent implements OnInit {


  /** {@inheritDoc AppComponent.currentUsername} */
  @Input() currentUsername: string;
  chart: any;
  equipmentTotaltemp: any[] = [];
  equipmentTotal: any[] = [];
  locationNumber: any;
  defaultImageUrl?: string;
  grapharray: any[] = [];
  equipPassPercentage = ``;
  ynUrls: any[] = [];
  constructor(private authService: AuthenticationService,
              private equipmentService: EquipmentTotalService,
              private router: Router,
              private sharedService: SharedServiceService) {
    this.currentUsername = ``;
    this.locationNumber = '';
    this.defaultImageUrl = `../../assets/costco-c-logo.webp`;
  }

  /**
   * OnInit life cycle hook. Called after constructor and the first OnChanges hook.
   */
  ngOnInit(): void {
    this.locationNumber = localStorage.getItem('locationNumber');
    this.getequipmentdetails();
  }
  /**
   * Checks the current user and authetication state.
   */
  checkUser(): void {
    this.currentUsername = this.authService.retrieveUsername() ?? `unknown user`;
  }
  getequipmentdetails(): void {
    this.equipmentService.getEquipmentTotal(this.locationNumber).subscribe(fetchedEquipmentDetails => {
      this.equipmentTotal = fetchedEquipmentDetails;
      const item = this.equipmentTotal.pop();
      this.grapharray.push(item.ttlpasstoday, item.ttlnottoday, item.ttlfailtoday, item.ttlunits);
      this.graphRender(this.grapharray);
      this.parseImageUrl();
    });
  }
  graphRender(graphadata: any): void {

    const passPer = this.getPercentage();
    this.equipPassPercentage = passPer[0];
    this.chart = new Chart('canvas', {
      type: 'doughnut',
      data: {
        labels: ['Passed', 'Due Today', 'Failed'],
        datasets: [
          {
            data: this.getPercentage(),
            backgroundColor: ['#198925', '#ffbf1f', ' #c52a1a'],
            fill: false
          },
        ]
      },
      options: {
        legend: {
          display: false
        },
        tooltips: {
          enabled: false
        },
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        cutoutPercentage: 85,
        aspectRatio: 1
      }
    });
  }
  parseImageUrl(): void {
    for (const [key, value] of Object.entries(this.equipmentTotal)) {
      let equipmentImageJSON: EquipmentImage;
      const equipmentType = value.equiptype || '';
      this.equipmentService.getEquipmentImage(equipmentType).subscribe(fetchedEquipmentImageJSON => {
        equipmentImageJSON = fetchedEquipmentImageJSON;
        value.equipmentimgurl = equipmentImageJSON === null ? (value.equipmentimgurl || this.defaultImageUrl) : equipmentImageJSON.url;
      });
    }
  }
  eachAction(ynFormat: string, actionType: string): void {
    this.sharedService.changeNav(ynFormat);
    if (actionType === 'search') {
      this.router.navigate(['search']);
    }
    if (actionType === 'reports') {
      this.router.navigate(['reports']);
    }
  }

  getPercentage(): any[] {
    const temparr: any[] = [];
    const passPercentage = ((this.grapharray[0] / this.grapharray[3]) * 100).toFixed();
    const duePercentage = ((this.grapharray[1] / this.grapharray[3]) * 100).toFixed();
    const failPercentage = ((this.grapharray[2] / this.grapharray[3]) * 100).toFixed();
    temparr.push(passPercentage, duePercentage, failPercentage);
    return temparr;
  }
  eqpAction(equipType: string, actionType: string): void {

    this.equipmentService.getYNurl().subscribe(urls => {
      this.ynUrls = urls;

      const result = this.ynUrls.filter((x) => x.equip === equipType.trim());
      for (let [key, item] of result.entries()) {
        if (actionType === 'due') {
          this.sharedService.changeNav(item.due);
          this.router.navigate(['search']);
        }
        if (actionType === 'outofservice') {
          this.sharedService.changeNav(item.outofservice);
          this.router.navigate(['search']);
        }
      }
    });
  }
}
