import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap} from '@angular/router';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ChecklistEquipmentDetailsComponent } from './checklist-equipment-details.component';

describe('EquipmentDetailsComponent', () => {
  let component: ChecklistEquipmentDetailsComponent;
  let fixture: ComponentFixture<ChecklistEquipmentDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChecklistEquipmentDetailsComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        {provide: ActivatedRoute, useValue:
          {
            snapshot: {
              paramMap: convertToParamMap([{equipmentID: '6'}])
            }
          // {
          //   params: of({equipmentType: 'F'}, {equipmentID: '6'})
          // }
          }
        }
      ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChecklistEquipmentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
