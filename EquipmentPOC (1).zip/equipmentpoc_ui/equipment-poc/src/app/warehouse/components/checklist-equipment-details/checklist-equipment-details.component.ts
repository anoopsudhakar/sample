import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../common/backend/authentication.service';
import { ActivatedRoute} from '@angular/router';
// services
import { EquipmentDetailsService } from '../../services/equipment-details.service';
import { GetequipimageService} from '../../services/getequipimage.service';
// models
import { EquipmentDetails} from '../../models/equipment-details.model';
import { EquipmentImage} from '../../../common/models/equipment-image';

import { mockEquipmentDetails } from '../../../common/backend/mock-data';

@Component({
  selector: 'app-checklist-equipment-details',
  templateUrl: './checklist-equipment-details.component.html',
  styleUrls: ['./checklist-equipment-details.component.less']
})
export class ChecklistEquipmentDetailsComponent implements OnInit {
  equipmentDetails: EquipmentDetails[] = [];
  locationNumber: string;
  equipmentID: string;
  defaultImageUrl?: string;
  equipmentimgurl: string;

  constructor(private auth: AuthenticationService,
              private route: ActivatedRoute,
              private equipmentDetailsService: EquipmentDetailsService,
              private equipmentImageService: GetequipimageService) {
                this.locationNumber = '';
                this.equipmentID = '';
                this.defaultImageUrl = `../../assets/costco-c-logo.webp`;
                this.equipmentimgurl = this.defaultImageUrl;
              }

  ngOnInit(): void {
    const lsLocationNumber = localStorage.getItem('locationNumber');
    this.locationNumber = lsLocationNumber ? lsLocationNumber?.padStart(5, '0')  : '';

    const equipmentIDParam = this.route.snapshot.paramMap.get('equipmentID');
    this.equipmentID = equipmentIDParam ? equipmentIDParam.trim() : '';

    // this.equipmentService.getRecentEquipment('00003', '00171', 'BNW').subscribe(fetchedRecentEquipments => {
    this.equipmentDetailsService.getEquipmentDetails(this.locationNumber, this.equipmentID).subscribe(fetchedEquipmentDetails => {
      this.equipmentDetails = fetchedEquipmentDetails;
      this.parseImageUrl();
    });

    // this.equipmentDetails = mockEquipmentDetails;
  }

  parseImageUrl(): void {
    for (const [key, value] of Object.entries(this.equipmentDetails)){
      let equipmentImageJSON: EquipmentImage;
      const equipmentType = value.equiptype || '';

      // this.equipmentImageService.getEquipmentImage('V').subscribe(fetchedEquipmentImageJSON => {
      this.equipmentImageService.getEquipmentImage(equipmentType).subscribe(fetchedEquipmentImageJSON => {
        equipmentImageJSON = fetchedEquipmentImageJSON;
        this.equipmentimgurl = equipmentImageJSON.url === undefined
                                                        ? this.equipmentimgurl
                                                        : equipmentImageJSON.url;

        console.log(this.equipmentimgurl);
        // equipmentImageJSON.url === undefined ? this.defaultImageUrl : equipmentImageJSON.url;
      });
    }
  }

}
