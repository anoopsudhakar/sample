import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute} from '@angular/router';
import { EquipmentChecklistRecentlyCompletedComponent } from './equipment-checklist-recently-completed.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
// import { EquipmentService } from '../../services/equipment.service';
// import { RecentEquipment} from '../../models/recent-equipment';
import { of } from 'rxjs';

describe('RecentEquipmentListComponent', () => {
  let component: EquipmentChecklistRecentlyCompletedComponent;
  let fixture: ComponentFixture<EquipmentChecklistRecentlyCompletedComponent>;
  // let equipmentService: EquipmentService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EquipmentChecklistRecentlyCompletedComponent ],
      imports: [HttpClientTestingModule],
      providers: [
        {provide: ActivatedRoute, useValue: {
          params: of({productId: 123})
        }},
        // {provide: EquipmentService, useValue: {
        //   params: of({limit: '3', location: '00171', userInitials: 'BNW'})
        // }},
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentChecklistRecentlyCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
