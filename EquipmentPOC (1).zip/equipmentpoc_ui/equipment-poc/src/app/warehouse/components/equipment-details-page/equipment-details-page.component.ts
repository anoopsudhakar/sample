
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';

import { EquipmentDetailsViewModel } from '../../viewmodels/equipment-details.viewmodel';
import { EquipmentChecklistHistoriesViewModel } from '../../viewmodels/equipment-checklist-histories.viewmodel';

import { EquipmentDetailsService } from '../../services/equipment-details.service';
import { EquipmentChecklistHistoryService } from '../../services/equipment-checklist-history.service';
import { EquipmentDetailsMapper } from '../../mappers/equipment-details.mapper';
import { EquipmentChecklistHistoryMapper } from '../../mappers/equipment-checklist-history.mapper';

import { mockEquipmentDetails, mockEquipmentChecklistHistory } from '../../../common/backend/mock-data';
import { ServiceStatusEnum } from '../../viewmodels/enums/service-status.enum';
import { PassOrFailEnum } from '../../viewmodels/enums/pass-or-fail.enum';

@Component({
    selector: 'app-equipment-details-page',
    templateUrl: './equipment-details-page.component.html',
    styleUrls: ['./equipment-details-page.component.less']
})
export class EquipmentDetailsPageComponent implements OnInit {
    ServiceStatus = ServiceStatusEnum;
    PassOrFail = PassOrFailEnum;

    equipmentDetailsVM!: EquipmentDetailsViewModel;
    equipmentChecklistHistoriesVM!: EquipmentChecklistHistoriesViewModel;
    defaultImageUrl: string;
    locationNumber: string;
    equipmentID: string;

    constructor(private route: ActivatedRoute,
                private equipmentDetailsService: EquipmentDetailsService,
                private equipmentChecklistHistoryService: EquipmentChecklistHistoryService,
                private equipmentDetailsMapper: EquipmentDetailsMapper,
                private equipmentChecklistHistoryMapper: EquipmentChecklistHistoryMapper) {
        this.defaultImageUrl = `../../assets/costco-c-logo.webp`;
        this.equipmentDetailsVM = new EquipmentDetailsViewModel();
        this.equipmentChecklistHistoriesVM = new EquipmentChecklistHistoriesViewModel();
        this.locationNumber = '';
        this.equipmentID = '';
    }

    ngOnInit(): void {
        this.getUrlParametersAndLocalStorage();
        // this.getEquipmentDetails();
        // this.getEquipmentHistory();
        this.mockAllData();
    }

    getUrlParametersAndLocalStorage(): void {
        const equipmentIDParam = this.route.snapshot.paramMap.get('equipmentID');
        this.equipmentID = equipmentIDParam ? equipmentIDParam.trim() : '';

        const locationNumberParam = this.route.snapshot.paramMap.get('locationNumber');
        const locationNumberLocal = localStorage.getItem('locationNumber');

        this.locationNumber = locationNumberParam ? locationNumberParam : locationNumberLocal ?? '';
        this.locationNumber = this.locationNumber.trim().padStart(5, '0');
    }

    getEquipmentDetails(): void {
        this.equipmentDetailsService.getEquipmentDetails(this.locationNumber, this.equipmentID).subscribe(obj => {
          this.equipmentDetailsVM = this.equipmentDetailsMapper.mapToEquipmentDetailsViewModel(obj);
          // this.parseImageUrl();
        });
    }

    getEquipmentHistory(): void {
        this.equipmentChecklistHistoryService.getEquipmentChecklistHistory(
            this.locationNumber,
            this.equipmentDetailsVM.equipmentUnit,
            this.equipmentDetailsVM.lastCheckDate,
            `9999`,
            `5`).subscribe(obj => {
                this.equipmentChecklistHistoriesVM = this.equipmentChecklistHistoryMapper.mapToEquipmentChecklistHistories(obj);
            }
        );

    }

    getImageUrl(url?: string): string {
        return url ?? this.defaultImageUrl;
      }

    mockAllData(): void {
        this.defaultImageUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Britishblue.jpg/372px-Britishblue.jpg';
        this.defaultImageUrl = 'https://content.syndigo.com/legacy/sp/a/nkxmEvEo_L.jpg';
        this.equipmentDetailsVM = this.equipmentDetailsMapper.mapToEquipmentDetailsViewModel(mockEquipmentDetails); /* Mock Code */
        this.equipmentChecklistHistoriesVM = this.equipmentChecklistHistoryMapper
            .mapToEquipmentChecklistHistories(mockEquipmentChecklistHistory); /* Mock Code */
    }
}
