import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { EquipmentChecklist } from '../../models/equipment-checklist.model';
import { ChecklistPutResults } from '../../models/equipment-checkliust-put-results.model';
import { ChecklistService } from '../../services/checklist.service';
import { AuthenticationService } from '../../../common/backend/authentication.service';
import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';
import { WebcamImage } from 'ngx-webcam';

import { mockEquipmentChecklist } from '../../../common/backend/mock-data';
import { error } from 'protractor';

@Component({
  selector: 'app-checklist',
  templateUrl: './checklist.component.html',
  styleUrls: ['./checklist.component.less'],
  providers: [DatePipe]
})
export class ChecklistComponent implements OnInit {
  equipmentChecklistItems: EquipmentChecklist[] = [];
  selectedIndexes = [] as number[];

  locationNumber: string;
  employeeInitials: string;
  equipmentType: string;
  equipmentID: string;

  myDate: string;

  displayWebCam = false;
  webcamImages: WebcamImage[] = [];

  constructor(private route: ActivatedRoute,
              private location: Location,
              private auth: AuthenticationService,
              private checklistService: ChecklistService,
              private datePipe: DatePipe) {
      this.locationNumber = '';
      this.employeeInitials = '';
      this.equipmentType = '';
      this.equipmentID = '';
      // this.myDate = '';
      this.myDate = new DatePipe('en-US').transform(new Date(), 'yyyy-MM-dd') || '';
  }

  ngOnInit(): void {

    // this.myDate = this.datePipe.transform(this.myDate, 'yyyy-MM-dd') || '';
    const lsLocationNumber = localStorage.getItem('locationNumber');
    this.locationNumber = lsLocationNumber ? lsLocationNumber?.padStart(5, '0')  : '';

    const lsEmployeeInitials = localStorage.getItem('employeeInitials');
    this.employeeInitials = lsEmployeeInitials ? lsEmployeeInitials : '';

    const equipmentTypeParam = this.route.snapshot.paramMap.get('equipmentType');
    this.equipmentType = equipmentTypeParam ? equipmentTypeParam : '';

    const equipmentIDParam = this.route.snapshot.paramMap.get('equipmentID');
    this.equipmentID = equipmentIDParam ? equipmentIDParam.trim() : '';


    this.checklistService.getEquipmentChecklist(this.equipmentType).subscribe(fetchedChecklist => {
       this.equipmentChecklistItems = fetchedChecklist;
    });

    // this.equipmentChecklistItems = mockEquipmentChecklist;
  }

  onSubmit(checklistItem: any ): void{

    let checkCodeArrayString = '';
    let checkResultsArrayString = '';
    let passOrFailVal = '';
    let hours = '';

    for (const [key, value] of Object.entries(checklistItem)) {
      // console.log(`${key}: ${value}`);
      if (!(isNaN(Number(key)))) {
        checkCodeArrayString += (key.padStart(2, '0'));
        checkResultsArrayString += value;
      }

      if (key.trim() === 'hours') {
        hours += value;
      }
    }

    passOrFailVal = (checkResultsArrayString.search('[F]') === -1) ? 'P' : 'F';


    /*     console.log(this.equipmentID);
    console.log(this.equipmentType);
    console.log(this.locationNumber);
    console.log(this.employeeInitials);
    console.log(hours);
    console.log(passOrFailVal);
    console.log(this.myDate);
    console.log(checkCodeArrayString);
    console.log(checkResultsArrayString); */


    const equipUnit: string = this.equipmentID;
    const equipType: string = this.equipmentType;
    const equipWhse: string = this.locationNumber;
    const checkUser: string = this.employeeInitials;
    const checkHour: string = hours;
    const passOrFail: string = passOrFailVal;
    const checkDate: string = this.myDate.toString();
    const checkTime = '0000';
    const checkCode: string = checkCodeArrayString;
    const checkResult: string = checkResultsArrayString;
    this.checklistService.postEquipmentChecklist(
      equipUnit, equipType, equipWhse, checkUser, checkHour, passOrFail, checkDate, checkTime, checkCode, checkResult
    ).subscribe(fetchedCheckDateTimeJSON => {
      const checklistdate = this.datePipe.transform(fetchedCheckDateTimeJSON.checkdate, 'yyyyMMdd');
      const checklisttime = fetchedCheckDateTimeJSON.checktime;
      const checklistDatetime = checklistdate + checklisttime;

      this.webcamImages.forEach( (webcamImage, i) => {
        const photoIndex = (i + 1).toString();
        const equipPhotoName = equipWhse + equipUnit + equipType + checklistDatetime + photoIndex;
        const modifiedBase64ImageString = webcamImage.imageAsDataUrl.substr(23); // ignores the 'data:image/jpeg;base64,' at the beginning
        // console.log(webcamImage);
        // console.log(equipPhotoName);
        // console.log(equipUnit);
        // console.log(equipWhse);
        // console.log(modifiedBase64ImageString);

        //  PostEquipmentChecklistPhoto(equipImgName, EquipID, location, photoNumber, checklistDateTime, equipImgData);
        this.checklistService.PostEquipmentChecklistPhoto
                                (equipPhotoName, equipUnit, equipType, equipWhse, photoIndex, checklistDatetime, modifiedBase64ImageString)
                             .subscribe(result => {
                               // console.log(result);
                               // TODO: Handle return from PostEquipmentChecklistPhoto Webservice
                               // a good post returns 'true'
                             });
      });

    }, err => {
      console.log(err);
    }, () => {
      console.log('submit completed');
      this.location.back();
    });

  }

  toggleShortLongText(i: number): void {
    if (this.selectedIndexes.indexOf(i) === -1) {
      this.selectedIndexes.push(i);
    }
    else {
      const index = this.selectedIndexes.indexOf(i);
      this.selectedIndexes.splice(index, 1);
    }
  }

  showHideWebCam(): void {
    this.displayWebCam = !this.displayWebCam;
  }

  handleImage(webcamImage: WebcamImage): void {
    this.webcamImages.push(webcamImage);
    this.displayWebCam = false;
    console.log(webcamImage);
  }

  removeImage(i: number): void {
    this.webcamImages.splice(i, 1);
  }

  formatTime(timeString: string): string {
    let modifiedTimeString = '';
    modifiedTimeString = timeString.padStart(4, '0');
    modifiedTimeString = [modifiedTimeString.slice(0, 2), ':', modifiedTimeString.slice(2)].join('');

    return modifiedTimeString;
  }

}


