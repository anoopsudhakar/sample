export class ChecklistPutResults {
  checkdate!: string;
  checktime!: string;
  putchecklist!: [];
}
