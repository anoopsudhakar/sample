export class EquipmentChecklist {
    equipChklistItemDesc: string | undefined;
    equipChklistItemDetail: string | undefined;
    url: string | undefined;
    container: string | undefined;
    fileName: string | undefined;
    strorageAccount: string | undefined;
    partitionKey: string | undefined;
    rowKey: string | undefined;
    timestamp: string | undefined;
    eTag: string | undefined;
}
