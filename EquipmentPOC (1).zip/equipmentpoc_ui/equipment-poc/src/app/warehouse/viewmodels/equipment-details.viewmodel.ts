import { PassOrFailEnum } from './enums/pass-or-fail.enum';
import { ServiceStatusEnum } from './enums/service-status.enum';

export class EquipmentDetailsViewModel {
    equipmentWarehouse!: string;
    equipmentUnit!: string;
    lastStatus!: PassOrFailEnum;
    lastCheckDate!: string;
    LastCheckTime!: string; /** TODO: IS THIS NOT INCLUDED IN THE SERVICE? */
    hoursUsed!: string;
    serviceStatus!: ServiceStatusEnum;
    equipmentType!: string;
    equipmentDescription!: string;
    lastUser!: string;
    manufacturer!: string;
    equipmentYear!: string;
    vinNumber!: string;
}
