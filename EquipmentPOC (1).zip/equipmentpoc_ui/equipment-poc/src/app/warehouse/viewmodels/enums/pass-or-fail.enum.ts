export enum PassOrFailEnum {
    Passed = 'passed',
    Failed = 'failed',
    DueToday = 'due-today'
}
