import { EquipmentChecklistHistoryEntryViewModel } from './equipment-checklist-history-entry.viewmodel';

export class EquipmentChecklistHistoriesViewModel {
    labels!: string[];
    entries!: EquipmentChecklistHistoryEntryViewModel[];
}
