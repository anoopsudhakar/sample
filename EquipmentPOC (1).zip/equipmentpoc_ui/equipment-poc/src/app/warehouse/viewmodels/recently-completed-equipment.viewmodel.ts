import { RecentEquipmentViewModel } from './recent-equipment.viewmodel';

export class RecentlyCompletedEquipmentViewModel {
    recentEquipments!: RecentEquipmentViewModel[];
}
