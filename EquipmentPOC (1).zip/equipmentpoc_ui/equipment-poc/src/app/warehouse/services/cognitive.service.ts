import { Injectable } from '@angular/core';
import { CancellationDetails, CancellationReason, ResultReason, AudioConfig, SpeechConfig, SpeechRecognizer, PhraseListGrammar} from 'microsoft-cognitiveservices-speech-sdk';

@Injectable({
  providedIn: 'root'
})
export class CognitiveService {
  private speechConfig: SpeechConfig;
  private audioConfig: AudioConfig;
  private speechRecognizer: SpeechRecognizer;
  // Setup for Continious Recognizer
  private recognizing: boolean;
  private innerHtml = '';
  private lastRecognized = '';

  constructor() {
    this.speechConfig = SpeechConfig.fromSubscription('subscriptionKeyHere', 'westus');
    this.audioConfig = AudioConfig.fromDefaultMicrophoneInput();
    this.speechConfig.speechRecognitionLanguage = 'en-US'; // Setting the recognition language to English.
    this.speechConfig.enableDictation(); // interpret word descriptions of sentence structures such as punctuation: "question mark" = "?"
    this.speechRecognizer = new SpeechRecognizer(this.speechConfig, this.audioConfig);

    this.recognizing = false; // Setup for Continious Recognizer

    // Improve recognition accuracy, add phrases or single words
    const phraseList = PhraseListGrammar.fromRecognizer(this.speechRecognizer);
    phraseList.addPhrase('Costco');
    phraseList.addPhrase('LTL');
  }

  public speechToText(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.speechRecognizer.recognizeOnceAsync(result => {
        let text = '';
        switch (result.reason) {
          case ResultReason.RecognizedSpeech:
            text = result.text;
            break;
          case ResultReason.NoMatch:
            text = 'Speech could not be recognized.';
            reject(text);
            break;
          case ResultReason.Canceled:
            const cancellation = CancellationDetails.fromResult(result);
            text = 'Cancelled: Reason= ' + cancellation.reason;
            if (cancellation.reason === CancellationReason.Error) {
              text = 'Canceled: ' + cancellation.ErrorCode;
            }
            reject(text);
            break;
        }
        resolve(text);
      });
    });
  }


  public startContinousRecognizer(): void {
    this.speechRecognizer.recognizing = (s, e) => {
      console.log(`RECOGNIZING: Text=${e.result.text}`);
    };

    this.speechRecognizer.recognized = (s, e) => {
      if (e.result.reason === ResultReason.RecognizedSpeech) {
          console.log(`RECOGNIZED: Text=${e.result.text}`);
      }
      else if (e.result.reason === ResultReason.NoMatch) {
          console.log('NOMATCH: Speech could not be recognized.');
      }
    };

    this.speechRecognizer.canceled = (s, e) => {
      console.log(`CANCELED: Reason=${e.reason}`);

      if (e.reason === CancellationReason.Error) {
          console.log(`"CANCELED: ErrorCode=${e.errorCode}`);
          console.log(`"CANCELED: ErrorDetails=${e.errorDetails}`);
          console.log('CANCELED: Did you update the subscription info?');
      }

      this.speechRecognizer.stopContinuousRecognitionAsync();
    };

    this.speechRecognizer.sessionStopped = (s, e) => {
      console.log('\n    Session stopped event.');
      this.speechRecognizer.stopContinuousRecognitionAsync();
    };

    this.speechRecognizer.startContinuousRecognitionAsync();
  }


  public startContinousSpeechToText(): void {
    if (this.recognizing) {
      this.stopContinousSpeechToText();
      this.recognizing = false;
    }
    else {
      this.recognizing = true;
      console.log('record');
      this.speechRecognizer.recognizing = this.speechRecognizer.recognized = this.recognizerCallback.bind(this);
      this.speechRecognizer.startContinuousRecognitionAsync();
    }
  }

  private recognizerCallback(s: any, e: any): void {
    console.log(e.result.text);
    const reason = ResultReason[e.result.reason];
    console.log(reason);
    if (reason === 'RecognizingSpeech') {
      this.innerHtml = this.lastRecognized + e.result.text;
    }
    this.lastRecognized += e.result.text + '\r\n';
    this.innerHtml = this.lastRecognized;
  }

  private stopContinousSpeechToText(): void {
    this.speechRecognizer.stopContinuousRecognitionAsync(
      this.stopRecognizer.bind(this),
      (err) => {
        this.stopRecognizer.bind(this);
        console.error(err);
      }
    );
  }

  private stopRecognizer(): void {
    this.speechRecognizer.close();
    console.log('stopped');
  }
}
