import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { EquipmentChecklist } from '../models/equipment-checklist.model';
import { ChecklistPutResults } from '../models/equipment-checkliust-put-results.model';
import { catchError } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })
};

@Injectable({
  providedIn: 'root'
})
export class ChecklistService {
  public checklistServicesUrl = 'https://equipmentpocservices.azurewebsites.net/api/EquipmentServices';

  constructor(private http: HttpClient) { }

   /* Web Service "GetCheckList" Depricated */
   /*
  getEquipmentChecklist(equipmentType: string): Observable<EquipmentChecklist[]> {
    console.log(`${this.checklistServicesUrl}/GetCheckList/${equipmentType}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/F`);
    return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/${equipmentType}/`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }
  */

  getEquipmentChecklist(equipmentType: string): Observable<EquipmentChecklist[]> {
    console.log(`${this.checklistServicesUrl}/GetEquipChkListImages/${equipmentType}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/F`);
    return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetEquipChkListImages/${equipmentType}/`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }

  postEquipmentChecklist(
    equipUnit: string, equipType: string, equipWhse: string,
    checkUser: string, checkHour: string, passOrFail: string,
    checkDate: string, checkTime: string, checkCode: string, checkResult: string
  ): Observable<ChecklistPutResults> {
    console.log(`${this.checklistServicesUrl}/PutEquipCheckList/${equipUnit}/${equipType}/${equipWhse}/${checkUser}/${checkHour}/${passOrFail}/${checkDate}/${checkTime}/${checkCode}/${checkResult}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/F`);
    return this.http.put<ChecklistPutResults>(`${this.checklistServicesUrl}/PutEquipCheckList/${equipUnit}/${equipType}/${equipWhse}/${checkUser}/${checkHour}/${passOrFail}/${checkDate}/${checkTime}/${checkCode}/${checkResult}/`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }

  PostEquipmentChecklistPhoto(equipImgName: string, EquipID: string, equipType: string,
                              location: string, photoNumber: string,
                              checklistDateTime: string, equipImgData: string): Observable<EquipmentChecklist[]> {
    // API: ../InsertSaveChecklistPhoto/{imgName}/{pk}/{rk}/{checklistDateTime}/{EquipID}/{loc}
    // e.g: ../InsertSaveChecklistPhoto/171EP1120210216143dot21/171EP1120210216143dot11/21/202103091128/EP11/00171

    const httpOptions2 = {
      headers: new HttpHeaders({
        'Content-Type': 'text/json',
        Accept: 'text/plain',
      })
    };

    const pk = `${location}${EquipID}${equipType}${checklistDateTime}`;
    console.log(`${this.checklistServicesUrl}/InsertSaveChecklistPhoto/${equipImgName}/${pk}/${photoNumber}/${checklistDateTime}/${EquipID}/${location}`);

    return this.http.put<any[]>(
      `${this.checklistServicesUrl}/InsertSaveChecklistPhoto/${equipImgName}/${pk}/${photoNumber}/${checklistDateTime}/${EquipID}/${location}`, JSON.stringify(equipImgData), httpOptions2)
    .pipe(
      catchError(this.handleError)
    );
  }


  private handleError(error: HttpErrorResponse): Observable<any> {
    console.log(error.message);
    return throwError('A data error occurred, please try again.');
  }

}
