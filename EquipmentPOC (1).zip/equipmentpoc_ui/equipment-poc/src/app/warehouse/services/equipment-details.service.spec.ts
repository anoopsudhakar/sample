import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { EquipmentDetailsService } from './equipment-details.service';

describe('EquipmentService', () => {
  let service: EquipmentDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EquipmentDetailsService]
    });
    service = TestBed.inject(EquipmentDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
