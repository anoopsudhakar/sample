import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { EquipmentImage } from '../../common/models/equipment-image';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })
};

@Injectable({
  providedIn: 'root'
})
export class GetequipimageService {

  ServicesUrl = 'https://equipmentpocservices.azurewebsites.net/api/EquipmentServices';

  constructor(private http: HttpClient) { }

  getEquipmentImage(equipmentType: string): Observable<EquipmentImage> {
    console.log(`${this.ServicesUrl}/GetEquipImage/${equipmentType}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetEquipImage/F`);
    return this.http.get<EquipmentImage>(`${this.ServicesUrl}/GetEquipImage/${equipmentType}/`, httpOptions);
  }
}
