/** TODO: Delete this. This is deprecated.
 * This is split into two services.
 */

// import { TestBed } from '@angular/core/testing';
// import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
// import { EquipmentService } from './equipment.service';

// describe('EquipmentService', () => {
//   let service: EquipmentService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpClientTestingModule],
//       providers: [EquipmentService]
//     });
//     service = TestBed.inject(EquipmentService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
