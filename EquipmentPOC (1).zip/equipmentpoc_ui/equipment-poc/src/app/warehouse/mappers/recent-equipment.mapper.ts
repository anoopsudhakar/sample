import { Injectable } from '@angular/core';
import { RecentEquipment } from '../models/recent-equipment.model';
import { PassOrFailEnum } from '../viewmodels/enums/pass-or-fail.enum';
import { ServiceStatusEnum } from '../viewmodels/enums/service-status.enum';
import { RecentEquipmentViewModel } from '../viewmodels/recent-equipment.viewmodel';

@Injectable({
    providedIn: 'root'
  })
export class RecentEquipmentMapper {

    defaultImage = `../assets/costco-c-logo.webp`;
    defaultDetailsVisibility = false;

    mapToRecentEquipmentViewModelArray(recentEquipments: RecentEquipment[]): RecentEquipmentViewModel[] {
        return recentEquipments.map(obj => {
            return ({
                equipmentId: obj.equipid?.trim(),
                equipmentType: obj.equiptype,
                equipmentDescription: obj.equipdesc.trim(),
                checkDate: obj.checkdate,
                checkTime: obj.checktime,
                passOrFail: obj.passorfail.toUpperCase() === `P`
                    ? PassOrFailEnum.Passed
                    : (obj.passorfail.toUpperCase() === `F`
                        ? PassOrFailEnum.Failed
                        : PassOrFailEnum.DueToday),
                serviceStatus: obj.inservice.toUpperCase() === `Y`
                    ? ServiceStatusEnum.InService
                    : ServiceStatusEnum.OutOfService,
                vinNumber: obj.vinno.trim(),
                equipmentImageUrl: this.defaultImage,
                areDetailsShown: this.defaultDetailsVisibility
            });
        });
    }

    mapToRecentEquipmentViewModel(recentEquipment: RecentEquipment): RecentEquipmentViewModel {
        const defaultImage = `../assets/costco-c-logo.webp`;

        return ({
            equipmentId: recentEquipment.equipid?.trim(),
            equipmentType: recentEquipment.equiptype,
            equipmentDescription: recentEquipment.equipdesc.trim(),
            checkDate: recentEquipment.checkdate,
            checkTime: recentEquipment.checktime,
            passOrFail: recentEquipment.passorfail.toUpperCase() === `P`
                ? PassOrFailEnum.Passed
                : (recentEquipment.passorfail.toUpperCase() === `F`
                    ? PassOrFailEnum.Failed
                    : PassOrFailEnum.DueToday),
            serviceStatus: recentEquipment.inservice.toUpperCase() === `Y`
                ? ServiceStatusEnum.InService
                : ServiceStatusEnum.OutOfService,
            vinNumber: recentEquipment.vinno.trim(),
            equipmentImageUrl: this.defaultImage,
            areDetailsShown: this.defaultDetailsVisibility
        });
    }
}
