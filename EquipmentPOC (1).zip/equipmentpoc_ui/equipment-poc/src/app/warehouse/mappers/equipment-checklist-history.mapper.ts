import { Injectable } from '@angular/core';
import { EquipmentChecklistHistory } from '../models/equipment-checklist-history.model';
import { EquipmentChecklistHistoriesViewModel } from '../viewmodels/equipment-checklist-histories.viewmodel';
import { PassOrFailEnum } from '../viewmodels/enums/pass-or-fail.enum';

@Injectable({
    providedIn: 'root'
  })
export class EquipmentChecklistHistoryMapper {

    mapToEquipmentChecklistHistories(equipmentChecklistHistoryArray: EquipmentChecklistHistory[]): EquipmentChecklistHistoriesViewModel {
        return ({
            labels: equipmentChecklistHistoryArray[0].cda.toLocaleLowerCase()
                .split(/(.{35})/)
                .map(o => o.trim())
                .filter(p => /\S/.test(p)),
            entries: equipmentChecklistHistoryArray.map(obj => {
                return ({
                    checkDate: obj.chkdt,
                    checkUser: obj.chkuser,
                    statuses: obj.cra.split('').map(x => {
                        return x.toUpperCase() === `P`
                            ? PassOrFailEnum.Passed
                            : (x.toUpperCase() === `F` ? PassOrFailEnum.Failed : PassOrFailEnum.DueToday);
                        }).filter(s => s !== PassOrFailEnum.DueToday)
                });
            })
        });
    }
}
