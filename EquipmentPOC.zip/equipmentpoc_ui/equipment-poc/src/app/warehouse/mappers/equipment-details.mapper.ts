import { Injectable } from '@angular/core';
import { EquipmentDetails } from '../models/equipment-details.model';
import { EquipmentDetailsViewModel } from '../viewmodels/equipment-details.viewmodel';
import { ServiceStatusEnum } from '../viewmodels/enums/service-status.enum';
import { PassOrFailEnum } from '../viewmodels/enums/pass-or-fail.enum';

@Injectable({
    providedIn: 'root'
  })
export class EquipmentDetailsMapper {

    mapToEquipmentDetailsViewModel(equipmentDetails: EquipmentDetails[]): EquipmentDetailsViewModel {
        const obj = equipmentDetails[0];

        return ({
            equipmentWarehouse: obj.equipwhs,
            equipmentUnit: obj.equipunit,
            lastStatus: obj.laststs.toUpperCase() === `P`
                ? PassOrFailEnum.Passed
                : (obj.laststs.toUpperCase() === `F`
                    ? PassOrFailEnum.Failed
                    : PassOrFailEnum.DueToday),
            lastCheckDate: obj.lastchkdt,
            LastCheckTime: '', /** TODO: IS THIS NOT INCLUDED IN THE SERVICE? */
            hoursUsed: obj.hrsused,
            serviceStatus: obj.inservice.toUpperCase() === `Y`
                    ? ServiceStatusEnum.InService
                    : ServiceStatusEnum.OutOfService,
            equipmentType: obj.equiptype,
            equipmentDescription: obj.equipdesc.toLocaleLowerCase(),
            lastUser: obj.lastuser,
            manufacturer: obj.mfg.toLocaleLowerCase(),
            equipmentYear: obj.equipyear,
            vinNumber: obj.vinno
        });

    }
}
