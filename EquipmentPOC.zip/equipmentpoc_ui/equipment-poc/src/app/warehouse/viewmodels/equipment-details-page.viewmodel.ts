import { EquipmentDetailsViewModel } from './equipment-details.viewmodel';

export class EquipmentDetailsPageViewModel {
    equipmentDetails!: EquipmentDetailsViewModel;
}
