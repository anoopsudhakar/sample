import { ServiceStatusEnum } from './enums/service-status.enum';
import { PassOrFailEnum } from './enums/pass-or-fail.enum';

export class RecentEquipmentViewModel {
    equipmentId!: string;
    equipmentType!: string;
    equipmentDescription!: string;
    checkDate!: string;
    checkTime!: string;
    passOrFail!: PassOrFailEnum;
    serviceStatus!: ServiceStatusEnum;
    vinNumber!: string;
    equipmentImageUrl!: string;
    areDetailsShown!: boolean;
}
