export enum ServiceStatusEnum {
    InService = `In Service`,
    OutOfService = `Out of Service`
}
