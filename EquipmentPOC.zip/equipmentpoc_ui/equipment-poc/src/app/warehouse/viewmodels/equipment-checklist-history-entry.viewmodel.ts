import { PassOrFailEnum } from './enums/pass-or-fail.enum';


export class EquipmentChecklistHistoryEntryViewModel {
    checkDate!: string;
    checkUser!: string;
    statuses!: PassOrFailEnum[];
}
