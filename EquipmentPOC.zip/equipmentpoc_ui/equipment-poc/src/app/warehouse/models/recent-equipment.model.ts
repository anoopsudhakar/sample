export class RecentEquipment {
    equipid!: string;
    equiptype!: string;
    equipdesc!: string;
    checkdate!: string;
    checktime!: string;
    passorfail!: string;
    inservice!: string;
    vinno!: string;
}
