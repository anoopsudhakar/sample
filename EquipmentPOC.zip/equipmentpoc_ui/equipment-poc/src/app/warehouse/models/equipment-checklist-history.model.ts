export class EquipmentChecklistHistory {
    equipwhs!: string;
    equiptype!: string;
    equiptypedesc!: string | null;
    chkdt!: string;
    chktime!: string;
    chkuser!: string;
    chkhours!: string;
    cia!: string;
    cda!: string;
    cra!: string;
}
