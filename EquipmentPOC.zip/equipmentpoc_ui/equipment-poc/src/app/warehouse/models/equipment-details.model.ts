export class EquipmentDetails {
    equipwhs!: string;
    equipunit!: string;
    laststs!: string;
    lastchkdt!: string;
    // lastchktime!: string; /** TODO: IS THIS NOT INCLUDED IN THE SERVICE? */
    hrsused!: string;
    inservice!: string;
    equiptype!: string;
    equipdesc!: string;
    lastuser!: string;
    mfg!: string;
    equipyear!: string;
    vinno!: string;
}
