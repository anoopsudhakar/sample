import { Component, Input, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../common/backend/authentication.service';

@Component({
  selector: 'app-equipment-checklist',
  templateUrl: './equipment-checklist.component.html',
  styleUrls: ['./equipment-checklist.component.less']
})
export class EquipmentChecklistComponent implements OnInit {

  @Input() currentUsername: string;

  constructor(private authService: AuthenticationService) {
    this.currentUsername = ``;
  }

  ngOnInit(): void {
    this.checkUser();
    if (sessionStorage.getItem(`signed-in`) === `now`) {
      sessionStorage.removeItem(`signed-in`);
      location.reload();
    }
  }

  checkUser(): void {
    this.currentUsername = this.authService.retrieveUsername() ?? `unknown user`;
  }

}
