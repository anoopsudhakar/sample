import { Component, OnInit } from '@angular/core';
import { RecentEquipmentService } from '../../services/recent-equipment.service';
import { GetequipimageService} from '../../services/getequipimage.service';
import { EquipmentImage} from '../../../common/models/equipment-image';
import { RecentlyCompletedEquipmentViewModel } from '../../viewmodels/recently-completed-equipment.viewmodel';
import { RecentEquipmentViewModel } from '../../viewmodels/recent-equipment.viewmodel';
import { mockEquipments } from '../../../common/backend/mock-data';
import { RecentEquipmentMapper } from '../../mappers/recent-equipment.mapper';
import { PassOrFailEnum } from '../../viewmodels/enums/pass-or-fail.enum';
import { ServiceStatusEnum } from '../../viewmodels/enums/service-status.enum';


@Component({
  selector: 'app-equipment-checklist-recently-completed',
  templateUrl: './equipment-checklist-recently-completed.component.html',
  styleUrls: ['./equipment-checklist-recently-completed.component.less']
})

export class EquipmentChecklistRecentlyCompletedComponent implements OnInit {
  ServiceStatus = ServiceStatusEnum;
  PassOrFail = PassOrFailEnum;

  recentlyCompletedEquipmentVM!: RecentlyCompletedEquipmentViewModel;
  defaultImageUrl: string;

  currentLocation: string;

  constructor(private recentEquipmentService: RecentEquipmentService,
              private equipmentImageService: GetequipimageService,
              private mapper: RecentEquipmentMapper) {
    this.defaultImageUrl = `../../assets/costco-c-logo.webp`;
    this.recentlyCompletedEquipmentVM = new RecentlyCompletedEquipmentViewModel();
    this.recentlyCompletedEquipmentVM.recentEquipments = [];
    this.currentLocation = '';
  }

  ngOnInit(): void {
    const lsLocationNumber = localStorage.getItem('locationNumber');
    const lsEmployeeInitials = localStorage.getItem('employeeInitials');
    const locationNumber = lsLocationNumber ? lsLocationNumber?.padStart(5, '0')  : '';
    const employeeInitials = lsEmployeeInitials ? lsEmployeeInitials : '';

    this.currentLocation = locationNumber;

    this.recentEquipmentService.getRecentEquipment('00003', locationNumber, employeeInitials).subscribe(fetchedRecentEquipments => {
      this.recentlyCompletedEquipmentVM.recentEquipments = this.mapper.mapToRecentEquipmentViewModelArray(fetchedRecentEquipments);
      this.parseImageUrl();
    });

    this.recentEquipmentService.getRecentEquipmentDev('00003', locationNumber, employeeInitials).subscribe(fetchedRecentEquipments => {
      // this.recentlyCompletedEquipmentVM.recentEquipments = this.mapper.mapToRecentEquipmentViewModelArray(fetchedRecentEquipments);
      // this.parseImageUrl();
      console.log(fetchedRecentEquipments);
    });

    // this.mockAllData();
  }

  mockAllData(): void {
    this.recentlyCompletedEquipmentVM.recentEquipments = this.mapper.mapToRecentEquipmentViewModelArray(mockEquipments); /* Mock Code */
  }

  parseImageUrl(): void {
    for (const [key, value] of Object.entries(this.recentlyCompletedEquipmentVM.recentEquipments)){
      let equipmentImageJSON: EquipmentImage;
      const equipmentType = value.equipmentType || '';

      // this.equipmentImageService.getEquipmentImage('V').subscribe(fetchedEquipmentImageJSON => {
      this.equipmentImageService.getEquipmentImage(equipmentType).subscribe(fetchedEquipmentImageJSON => {
        equipmentImageJSON = fetchedEquipmentImageJSON;
        value.equipmentImageUrl = equipmentImageJSON === null ? value.equipmentImageUrl : equipmentImageJSON.url || '';
      });
    }
  }

  getImageUrl(url?: string): string {
    return url || (this.defaultImageUrl !== undefined ? this.defaultImageUrl : '');
  }

  formatTime(timeString: string): string {
    let modifiedTimeString = '';
    modifiedTimeString = timeString.padStart(4, '0');
    modifiedTimeString = [modifiedTimeString.slice(0, 2), ':', modifiedTimeString.slice(2)].join('');

    return modifiedTimeString;
  }

  toggleDetails(recentEquipmentVM: RecentEquipmentViewModel): void {
    recentEquipmentVM.areDetailsShown = !recentEquipmentVM.areDetailsShown;
  }
}
