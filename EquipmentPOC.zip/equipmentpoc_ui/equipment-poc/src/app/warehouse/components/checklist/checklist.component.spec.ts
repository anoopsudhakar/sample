import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap} from '@angular/router';
import { ChecklistComponent } from './checklist.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

describe('NewChecklistPageComponent', () => {
  let component: ChecklistComponent;
  let fixture: ComponentFixture<ChecklistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChecklistComponent ],
      imports: [HttpClientTestingModule , FormsModule, ReactiveFormsModule],
      providers: [
        {provide: ActivatedRoute, useValue:
          {
            snapshot: {
              paramMap: convertToParamMap([{equipmentType: '0'}, {equipmentID: '6'}])
            }
          // {
          //   params: of({equipmentType: 'F'}, {equipmentID: '6'})
          // }
          }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChecklistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
