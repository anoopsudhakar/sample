import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EquipmentChecklistHistory } from '../models/equipment-checklist-history.model';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })
};

@Injectable({
  providedIn: 'root'
})
export class EquipmentChecklistHistoryService {
    equipmentServicesUrl = `https://equipmentpocservices.azurewebsites.net/api/EquipmentServices`;

    constructor(private http: HttpClient) { }

    getEquipmentChecklistHistory(
        warehouse: string, unit: string, chkdate: string, chktime: string, rowcount: string): Observable<EquipmentChecklistHistory[]> {
        console.log(`${this.equipmentServicesUrl}/GetChkListHIST/${warehouse}/${unit}/${chkdate}/${chktime}/${rowcount}/`);
        return this.http.get<EquipmentChecklistHistory[]>(
            `${this.equipmentServicesUrl}/GetChkListHIST/${warehouse}/${unit}/${chkdate}/${chktime}/${rowcount}/`, httpOptions);
    }

}
