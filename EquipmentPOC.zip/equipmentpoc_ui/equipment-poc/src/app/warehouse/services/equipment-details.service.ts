import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EquipmentDetails } from '../models/equipment-details.model';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })
};

@Injectable({
  providedIn: 'root'
})
export class EquipmentDetailsService {
    equipmentServicesUrl = `https://equipmentpocservices.azurewebsites.net/api/EquipmentServices`;

    constructor(private http: HttpClient) { }

    getEquipmentDetails(location: string, equipmentId: string): Observable<EquipmentDetails[]> {
        console.log(`${this.equipmentServicesUrl}/GetEquipDetails/${location}/${equipmentId}/`);
        return this.http.get<EquipmentDetails[]>(`${this.equipmentServicesUrl}/GetEquipDetails/${location}/${equipmentId}/`, httpOptions);
    }

}
