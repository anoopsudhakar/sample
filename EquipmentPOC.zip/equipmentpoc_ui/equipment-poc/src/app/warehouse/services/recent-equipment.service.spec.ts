import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RecentEquipmentService } from './recent-equipment.service';

describe('EquipmentService', () => {
  let service: RecentEquipmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [RecentEquipmentService]
    });
    service = TestBed.inject(RecentEquipmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
