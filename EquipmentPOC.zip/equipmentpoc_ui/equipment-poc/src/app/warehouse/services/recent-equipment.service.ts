import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RecentEquipment } from '../models/recent-equipment.model';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
    Accept: '*/*'
  })
};

@Injectable({
  providedIn: 'root'
})
export class RecentEquipmentService {
    equipmentServicesUrl = `https://equipmentpocservices.azurewebsites.net/api/EquipmentServices`;

    constructor(private http: HttpClient) { }

    getRecentEquipment(limit: string, location: string, userInitials: string): Observable<RecentEquipment[]> {
        return this.http.get<RecentEquipment[]>(
            `${this.equipmentServicesUrl}/GetRecent/${limit}/${location}/${userInitials}/`, httpOptions);
    }

    getRecentEquipmentDev(limit: string, location: string, userInitials: string): Observable<any[]> {
        // return this.http.get<RecentEquipment[]>(`${this.equipmentServicesUrl}/GetRecent/00005/00171/BNW`);
        // console.log(`${this.equipmentServicesUrl}/GetRecent/${limit}/${location}/${userInitials}/`);
        return this.http.get<any[]>(
            `https://dev400.corp.costco.com:10011/Web-Services-for-IBM-i/api/equipment/recent?location=00171&user=AM&rowLimit=4`,
            httpOptions);
    }

}
