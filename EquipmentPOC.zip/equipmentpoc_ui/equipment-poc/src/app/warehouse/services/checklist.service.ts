import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { EquipmentChecklist } from '../models/equipment-checklist.model';
import { catchError } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'Application/json',
  })
};

@Injectable({
  providedIn: 'root'
})
export class ChecklistService {
  public checklistServicesUrl = 'https://equipmentpocservices.azurewebsites.net/api/EquipmentServices';

  constructor(private http: HttpClient) { }

   /* Web Service "GetCheckList" Depricated */
   /*
  getEquipmentChecklist(equipmentType: string): Observable<EquipmentChecklist[]> {
    console.log(`${this.checklistServicesUrl}/GetCheckList/${equipmentType}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/F`);
    return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/${equipmentType}/`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }
  */

  getEquipmentChecklist(equipmentType: string): Observable<EquipmentChecklist[]> {
    console.log(`${this.checklistServicesUrl}/GetEquipChkListImages/${equipmentType}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/F`);
    return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetEquipChkListImages/${equipmentType}/`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }

  postEquipmentChecklist(
    equipUnit: string, equipType: string, equipWhse: string,
    checkUser: string, checkHour: string, passOrFail: string,
    checkDate: string, checkTime: string, checkCode: string, checkResult: string
  ): Observable<EquipmentChecklist[]> {
    console.log(`${this.checklistServicesUrl}/PutEquipCheckList/${equipUnit}/${equipType}/${equipWhse}/${checkUser}/${checkHour}/${passOrFail}/${checkDate}/${checkTime}/${checkCode}/${checkResult}/`);
    // return this.http.get<EquipmentChecklist[]>(`${this.checklistServicesUrl}/GetCheckList/F`);
    return this.http.put<EquipmentChecklist[]>(`${this.checklistServicesUrl}/PutEquipCheckList/${equipUnit}/${equipType}/${equipWhse}/${checkUser}/${checkHour}/${passOrFail}/${checkDate}/${checkTime}/${checkCode}/${checkResult}/`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }



  private handleError(error: HttpErrorResponse): Observable<any> {
    console.log(error.message);
    return throwError('A data error occurred, please try again.');
  }

}
