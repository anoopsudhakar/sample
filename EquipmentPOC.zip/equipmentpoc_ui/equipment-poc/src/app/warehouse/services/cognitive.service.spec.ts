import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CognitiveService } from './cognitive.service';

describe('CognitiveService', () => {
  let service: CognitiveService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CognitiveService]
    });
    service = TestBed.inject(CognitiveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
