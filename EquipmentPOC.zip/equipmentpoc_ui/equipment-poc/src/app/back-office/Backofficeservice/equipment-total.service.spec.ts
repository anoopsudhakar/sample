import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { EquipmentTotalService } from './equipment-total.service';

describe('EquipmentTotalService', () => {
  let service: EquipmentTotalService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EquipmentTotalService]
    });
    service = TestBed.inject(EquipmentTotalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
