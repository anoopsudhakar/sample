import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../../backend/authentication.service';

@Component({
  selector: 'app-signin-page',
  templateUrl: './signin-page.component.html',
  styleUrls: ['./signin-page.component.less']
})
export class SigninPageComponent implements OnInit {
  locationNumber = '';
  employeeInitials = '';

  portal?: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthenticationService
  ) {
    this.portal = undefined;
  }

  ngOnInit(): void {
  }

  signin(): void {
    this.authService.signOut();

    localStorage.setItem('locationNumber', this.locationNumber);
    localStorage.setItem('employeeInitials', this.employeeInitials);

    if (this.portal === `warehouse`) {
      this.router.navigateByUrl('/warehouse');
    } else {
      this.router.navigateByUrl('/office');
    }

    this.authService.signIn(this.employeeInitials, this.locationNumber);
    sessionStorage.setItem('signed-in', 'now');
  }

}
