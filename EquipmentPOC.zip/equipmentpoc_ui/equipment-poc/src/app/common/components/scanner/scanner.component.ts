import { Component, OnInit, ViewChild } from '@angular/core';
import { BarcodeFormat } from '@zxing/library';
import { BehaviorSubject } from 'rxjs';
import { Router} from '@angular/router';
import { ZXingScannerComponent } from '@zxing/ngx-scanner';

// services
import { EquipmentDetailsService } from '../../../warehouse/services/equipment-details.service';
// models
import { EquipmentDetails} from '../../../warehouse/models/equipment-details.model';

@Component({
  selector: 'app-scanner',
  templateUrl: './scanner.component.html',
  styleUrls: ['./scanner.component.less']
})
export class ScannerComponent implements OnInit {
  availableDevices: MediaDeviceInfo[] = null as any;
  currentDevice: MediaDeviceInfo = null as any;
  hasDevices: boolean = null as any;
  qrResultString: string;
  hasPermission = false;
  torchEnabled = false;
  torchAvailable$ = new BehaviorSubject<boolean>(false);
  tryHarder = false;

  allowedFormats = [
      BarcodeFormat.QR_CODE,
      BarcodeFormat.EAN_13,
      BarcodeFormat.CODE_128,
      BarcodeFormat.DATA_MATRIX,
      BarcodeFormat.EAN_8
  ];
  @ViewChild('scanner')
  scanner?: ZXingScannerComponent;

  locationNumber: string;
  equipmentType: string;
  equipmentDetails: EquipmentDetails[] = [];

  constructor(private router: Router,
              private equipmentDetailsService: EquipmentDetailsService
              ) {
    this.qrResultString = null as any;
    this.equipmentType = '';
    this.locationNumber = '';
  }

  ngOnInit(): void {
    const lsLocationNumber = localStorage.getItem('locationNumber');
    this.locationNumber = lsLocationNumber ? lsLocationNumber?.padStart(5, '0')  : '';

    this.scanner?.camerasFound.subscribe((devices: MediaDeviceInfo[]) => {
      this.hasDevices = true;

      console.log('Devices: ', devices);
      this.availableDevices = devices;

      // selects the devices's back camera by default
      // for (const device of devices) {
      //     if (/back|rear|environment/gi.test(device.label)) {
      //         this.scanner.changeDevice(device);
      //         this.selectedDevice = device;
      //         break;
      //     }
      // }
    });

    this.scanner?.permissionResponse.subscribe(res => {
      this.hasPermission = res;

      console.log('hasPermission: ', res);
    });
  }

  clearResult(): void {
    this.qrResultString = null as any;
  }

  onCamerasFound(devices: MediaDeviceInfo[]): void {
    this.availableDevices = devices;
    // console.log(devices);
    this.hasDevices = Boolean(devices && devices.length);

    this.currentDevice = this.availableDevices[0]; // use first camera found
  }

  onCodeResult(resultString: string): void {
    this.qrResultString = '6'; // resultString;
    this.getEquipmentDetails(this.qrResultString );
  }

  startChecklist(): void {
    this.getEquipmentDetails(this.qrResultString );
  }

  onHasPermission(has: boolean): void {
    this.hasPermission = has;
  }

  onDeviceSelectChange(selected: any): void {
    const device = this.availableDevices.find(x => x.deviceId === selected.value);
    console.log(device);
    this.currentDevice = (device === undefined) ? null as any : (device  || null as any);
    this.scanner?.restart();
  }

  onTorchCompatible(isCompatible: boolean): void {
    this.torchAvailable$.next(isCompatible || false);
  }

  toggleTorch(): void {
    this.torchEnabled = !this.torchEnabled;
  }

  navigateToChecklist(): void {
    console.log(`/checklist/new/${this.equipmentType}/${this.qrResultString}`);
    this.router.navigateByUrl(`/checklist/new/${this.equipmentType}/${this.qrResultString}`);
  }
  getEquipmentDetails(equipmentID: string): void {
    this.equipmentDetailsService.getEquipmentDetails(this.locationNumber, equipmentID).subscribe(fetchedEquipmentDetails => {
      this.equipmentDetails = fetchedEquipmentDetails;
      this.equipmentType = this.equipmentDetails[0].equiptype;
      this.navigateToChecklist();
    });
  }

}


