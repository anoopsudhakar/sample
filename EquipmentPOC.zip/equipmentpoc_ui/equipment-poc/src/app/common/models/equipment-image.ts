export class EquipmentImage {
    url: string | undefined;
    container: string | undefined;
    equipDesc: string | undefined;
    fileName: string | undefined;
    storageAccount: string | undefined;
    partitionKey: string | undefined;
    rowKey: string | undefined;
    timestamp: string | undefined;
    eTag: string | undefined;
}
