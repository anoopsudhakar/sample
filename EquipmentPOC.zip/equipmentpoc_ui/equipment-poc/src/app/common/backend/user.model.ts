/**
 * Model class 'UserModel' for user credential in localStorage.
 */
export class UserModel {

    /** Username of the User. */
    public username: string;

    /** First Name of the User. */
    public firstName: string;

    /** First Name of the User. */
    public lastName: string;

    /** URL of of the User's avatar. */
    public avatarUrl: string;

    /**
     * Initializes a new instance of UserModel object.
     * @param init Used in assigning instantiation values.
     */
    public constructor(init?: Partial<UserModel>) {
        this.username = ``;
        this.avatarUrl = ``;
        this.firstName = ``;
        this.lastName = ``;
        Object.assign(this, init);
    }
}
