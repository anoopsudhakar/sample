import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatSliderModule } from '@angular/material/slider';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';

import { SigninPageComponent } from './common/components/signin-page/signin-page.component';
import { WebcamModule } from 'ngx-webcam';
import { CameraComponent } from './common/components/camera/camera.component';

import { UserMenuComponent } from './warehouse/components/user-menu/user-menu.component';
import { EquipmentChecklistComponent } from './warehouse/components/equipment-checklist/equipment-checklist.component';
import { ChecklistComponent } from './warehouse/components/checklist/checklist.component';
import { ChecklistEquipmentDetailsComponent } from './warehouse/components/checklist-equipment-details/checklist-equipment-details.component';
import { EquipmentChecklistRecentlyCompletedComponent } from './warehouse/components/equipment-checklist-recently-completed/equipment-checklist-recently-completed.component';

import { EquipmentDetailsPageComponent } from './warehouse/components/equipment-details-page/equipment-details-page.component';

import { BackOfficeHomeComponent } from './back-office/components/back-office-home/back-office-home.component';
import { WelcomeComponent } from './common/components/welcome/welcome.component';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { ScannerComponent } from './common/components/scanner/scanner.component';
import { SearchEquipmentComponent } from './common/components/search-equipment/search-equipment.component';

@NgModule({
  declarations: [
    AppComponent,
    EquipmentChecklistComponent,
    UserMenuComponent,
    ChecklistComponent,
    ChecklistEquipmentDetailsComponent,
    EquipmentChecklistRecentlyCompletedComponent,
    SigninPageComponent,
    BackOfficeHomeComponent,
    EquipmentDetailsPageComponent,
    CameraComponent,
    WelcomeComponent,
    ScannerComponent,
    SearchEquipmentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ZXingScannerModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatMenuModule,
    MatIconModule,
    MatSliderModule,
    MatRadioModule,
    MatCardModule,
    MatTooltipModule,
    MatButtonToggleModule,
    WebcamModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
